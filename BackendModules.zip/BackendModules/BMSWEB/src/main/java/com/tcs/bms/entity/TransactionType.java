package com.tcs.bms.entity;

public enum TransactionType {
    CASH_WITHDRAWAL,
    CASH_DEPOSIT,
    CASH_TRANSFER,
    PIN_CREATION,
    PIN_UPDATE
}
