export const environment = {
    production: false,
    apiUrl: 'http://localhost:8180/bms',
    tokenName :  "authToken",
    origin:'http://localhost:4200' 
  };